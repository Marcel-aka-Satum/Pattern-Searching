//
// Created by elias on 20/02/2022.
//

#ifndef OEFC___DFA_H
#define OEFC___DFA_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include "json.hpp"
#include <string>
#include <utility>
using namespace std;

using json = nlohmann::json;

class DFA{
private:
    json j;

public:
    DFA(const string& dfa){
        ifstream input(dfa);
        input >> j;
    }
    DFA(json v){
        j = std::move(v);
    }
    bool accepts(const string& s){
        bool states[j["states"].size()];
        string currentState;
        // hier kijk ik wat mijn starting state is en zet ik dat state true en geef dat door aan de var currentState
        for(int i = 0; i < j["states"].size(); i++){
            if (j["states"][i]["starting"] == true){
                states[i] = true;
                currentState = j["states"][i]["name"];
            }
        }
        // hier kijk ik of de char in de alphabet zit, zoniet dn zet ik de curr state nr een dead state.
        for (auto i: s) {
            string inp(1,i);
            bool inAlphabet = false;
            for (const auto & l : j["alphabet"]){
                if (inp == l){
                    inAlphabet = true;
                }
            }
            if (!inAlphabet){
                currentState = "DEAD STATE";
            }
            // hier kijk ik welke transitie het moet doen, door te kijken wat de currentState is en de input.
            for (int k = 0; k < j["transitions"].size(); k++){
                if ((j["transitions"][k]["from"] == currentState) and (j["transitions"][k]["input"] == inp)){
                    currentState = j["transitions"][k]["to"];
                    break;
                }
            }
        }
        // hier check ik waar mijn currentState is geindigd en of dat state een accepting state is, zoja return ik true anders false.
        for(int i = 0; i < j["states"].size(); i++){
            if (j["states"][i]["name"] == currentState){
                if (j["states"][i]["accepting"] == true)
                    return true;
                else
                    return false;
            }
        }
        return false;
    }
    void print(){
        cout << setw(4) << j << endl;
    }
};
#endif //OEFC___DFA_H