//
// Created by elias on 10/05/2022.
//

#ifndef PROJECT_TA_PATTERNSEARCHING_H
#define PROJECT_TA_PATTERNSEARCHING_H
#include <iostream>
#include <fstream>
#include <iomanip>
#include "json.hpp"
#include <string>
#include <utility>
#include <vector>
#include "string"
using namespace std;
using json = nlohmann::json;

class PatternSearching{
private:
    string regex1;
    string regex2;
    string tekstBestand;
public:
    PatternSearching(string& b, string& re){
        regex1 = re;
        ifstream input(b);
        input >> tekstBestand;
    }
    PatternSearching(string& b, string& re1, string& re2){
        regex1 = re1;
        regex2 = re2;
        ifstream input(b);
        input >> tekstBestand;
    }
};

#endif //PROJECT_TA_PATTERNSEARCHING_H
